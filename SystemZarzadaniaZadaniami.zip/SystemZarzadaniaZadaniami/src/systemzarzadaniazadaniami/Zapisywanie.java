
package systemzarzadaniazadaniami;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class Zapisywanie {
    private String nazwaPliku;
    
    
    public static boolean zapiszZadania(List<Zadania> aktualneZadania, String nazwaPliku){
        StringBuilder json = new StringBuilder();
        json.append("[\n");

        for(int i=0; i<aktualneZadania.size();i++){
            Zadania z = aktualneZadania.get(i);
            json.append("OTO TWOJA LISTA ZADAN:");
            json.append(" (\n");
            json.append("   \"id\": ").append(z.getId()).append(", \n");
            json.append("   \"nazwa\": \"").append(z.getNazwa()).append(", \n");
            json.append("   \"deadline\": ").append(z.getDeadline()).append(", \n");
            json.append("   \"Pracownik\": ").append(z.pracownik.getImie()+" "+z.pracownik.getNazwisko()).append(", \n");
            
            if(z.getStatus()==(1)){
                json.append("   \"Status\":  \"Ukonczono!\"");
            }
            else{
                json.append("   \"Status\":  \"W trakcie!\"");
            }
            
            json.append("  }");
            if (i < aktualneZadania.size() - 1) {
                 json.append(",");
}
            json.append("\n");
        }
        
        json.append("]");
        try{
        Files.writeString(Path.of(nazwaPliku), json.toString());
        
        return true;
    }catch(IOException e ){
        return false;
    }}
}

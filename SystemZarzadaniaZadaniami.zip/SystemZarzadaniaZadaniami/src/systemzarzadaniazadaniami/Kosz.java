
package systemzarzadaniazadaniami;

import java.util.ArrayList;
import java.util.List;
public class Kosz {
    private List <Zadania> kosz= new ArrayList<>();
    
    
    public void dodajDoKosza(Zadania zadanie){
        kosz.add(zadanie);
    }
    public void wyswietlUsuniete(){
        if(kosz.isEmpty()){
            System.out.println("Kosz jest pusty.");
            return;
        }
        for(int i=0;i<kosz.size();i++){
            if(kosz.get(i).getStatus()==1){
            System.out.println((i+1)+". "+kosz.get(i).getNazwa()+" " + "Deadline: "+kosz.get(i).getDeadline() +" dni. Status: Ukończono.");
            }
            else{
                System.out.println((i+1)+". "+kosz.get(i).getNazwa()+" " + "Deadline: "+kosz.get(i).getDeadline()+" dni. Status: w trakcie.");
                
        }
    }
}}


package systemzarzadaniazadaniami;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
public class SystemZarzadaniaZadaniami {
    
    
    
    
    
    
    
    
    
    public static void main(String[] args) {
        System.out.println("========System zarządzania zadaniami=========");
        try {
            Logowanie logowanie = new Logowanie("config.json");
                   if(!logowanie.zaloguj()){
                       System.out.println("Błędny login lub hasło!");
                       return;
                   }
            System.out.println("Zalogowano pomyślnie!");
        
        List<Projekt> projekty = new ArrayList<>();
        Scanner s = new Scanner(System.in);
        MenagerPracownikow menager = new MenagerPracownikow();
        Kosz kosz = new Kosz();
        while(true){
        System.out.println("Co chcesz zrobic: ");
        System.out.println("1. Wyswietl projekty.");
        System.out.println("2. Utworz projekt.");
        System.out.println("3. Utworz konto pracownika.");
        System.out.println("4. Usun konto pracownika.");
        System.out.println("9. Wyjdz");
        
        int wybor = wprowadzLiczbe.wprowadzInt(s);
        switch(wybor){
            case 1:
            if(projekty.isEmpty()){
                System.out.println("Brak utworzonych projektów");
            }else {
                System.out.println("Wybierz projekt do wyswietlenia: ");
                for (int i=0; i < projekty.size(); i++){
                    System.out.println(i + 1 + ". " + projekty.get(i).getNazwa());
                }
                int projektIndex = wprowadzLiczbe.wprowadzInt(s) -1 ;
                if(projektIndex>= 0 && projektIndex < projekty.size()){
                    projekty.get(projektIndex).wyswietlProjekt();
                    while(true){
                    System.out.println("Co chcesz teraz zrobic: ");
                    System.out.println("1. Wyswietl zadania.");
                    System.out.println("2. Dodaj zadanie.");
                    System.out.println("3. Usun zadanie.");
                    System.out.println("4. Zmien status.");
                    System.out.println("5. Przydziel pracownika do zadania.");
                    System.out.println("6. Zrób raport.");
                    System.out.println("7. Wyswietl usuniete.");
                    System.out.println("8. Zapisz zadania.");
                    System.out.println("9. Powrot.");
                    int wybor1 = wprowadzLiczbe.wprowadzInt(s);
                    switch(wybor1){
                        case 1:
                            projekty.get(projektIndex).wyswietlZadania();
                            break;
  
                        case 2:
                            s.nextLine();
                            System.out.println("Podaj nazwe zadania: ");
                            String nazwa = s.nextLine();
                            System.out.println("Podaj ilosc dni do ukonczenia zadania: ");
                            int deadline = wprowadzLiczbe.wprowadzInt(s);
                            projekty.get(projektIndex).dodajZadanie(nazwa, deadline);
                           
                            break;
                        case 3:
                        if(projekty.get(projektIndex).getLiczbazadan()==0){
                            System.out.println("Brak zadan do usuniecia.");
                            break;
                        }else {System.out.println("Które zadanie chcesz usunąć?");
                            projekty.get(projektIndex).wyswietlZadania();
                            int wybor2 = wprowadzLiczbe.wprowadzInt(s);;
                            if ( wybor2 < 1 || wybor2 > projekty.get(projektIndex).getLiczbazadan()){
                                System.out.println("Nieprawidlowy nr zadania.");
                                break;
                            }
                            int index = wybor2 -1;
                            Zadania usuniete = projekty.get(projektIndex).getZadanie(index);
                            kosz.dodajDoKosza(usuniete);
                            projekty.get(projektIndex).usunZadanie(index);
                            System.out.println("Zadanie przeniesione do kosza. ");
                        }
                            break;
                        case 4:
                        if(projekty.get(projektIndex).getLiczbazadan()==0){
                            System.out.println("Brak zadan.");
                            break;
                        }else{
                            System.out.println("Którego zadania chcesz zmienić status?");
                            projekty.get(projektIndex).wyswietlZadania();
                            int wybor4  = wprowadzLiczbe.wprowadzInt(s);;
                            projekty.get(projektIndex).zmienStatus(wybor4 - 1);
                        }
                            break;
                        
                        case 5:
                            if(projekty.get(projektIndex).getLiczbazadan()==0){
                            System.out.println("Brak zadan.");
                            break;
                            }
                            
                            System.out.println("Do którego zadania chcesz przydzielić pracownika?");
                            projekty.get(projektIndex).wyswietlZadania();
                            int nrZadania=wprowadzLiczbe.wprowadzInt(s);;
                            System.out.println("Wybierz pracownika:");
                            if(nrZadania<1 || nrZadania > projekty.get(projektIndex).getLiczbazadan()){
                                System.out.println("Nieprawidlowy wybor zadania.");
                                        break;
                            }if (menager.liczbaPracownikow()==0){
                                System.out.println("Brak pracownikow.");
                                break;
                            }
                           
                            menager.wyswietlPracownikow();
                            int nrPracownika= wprowadzLiczbe.wprowadzInt(s);
                            if (nrPracownika<1 || nrPracownika> menager.liczbaPracownikow()){
                                System.out.println("Nieprawidlowy wybor pracownika. ");
                                break;
                            }
                            Zadania zadanie = projekty.get(projektIndex).getZadanie(nrZadania -1 );
                            Pracownicy pracownik = menager.getPracownik(nrPracownika -1 );
                            zadanie.przypiszPracownika(pracownik);
                            System.out.println("Pracownik przypisany pomyślnie!");
                            break;
                        case 6:
                            Raport.zrobRaport(projekty.get(projektIndex));
                            break;
                        case 7:
                            System.out.println("USUNIETE ZADANIA:");
                            kosz.wyswietlUsuniete();
                            break;
                        case 8:
                            s.nextLine();
                            System.out.println("Podaj nazwe pliku: ");
                            nazwa=s.nextLine();
                            boolean zapisano = Zapisywanie.zapiszZadania(projekty.get(projektIndex).getAktualneZadania(),nazwa);
                            if(zapisano){
                                System.out.println("Zadania zapisane poprawnie");
                            }else {
                                System.out.println("Bład zapisu");
                            }
                            break;
                        case 9:
                            
                            break;
                    }
                    if(wybor1 == 9 ){
                        break;
                    }
                    }
                } else {
                    System.out.println("Nieprawidlowy wybor");
                }
            }break;
            case 2:
                
            s.nextLine();
            System.out.println("Podaj nazwe projektu");
            String nazwa = s.nextLine();
            System.out.println("Podaj maksymalna liczbe zadan: ");
            int zadania = wprowadzLiczbe.wprowadzInt(s);
            Projekt a = new Projekt(nazwa, zadania);
            projekty.add(a);
            System.out.println("Projekt utworzony pomyslnie!");
            break;
            case 3:
                s.nextLine();
                System.out.println("Podaj imie pracownika: ");
                String imie= s.nextLine();
                System.out.println("Podaj nazwisko: ");
                String nazwisko=s.nextLine();
        
                menager.dodajPracownika(imie, nazwisko);
                break;
            case 4:
                if(menager.liczbaPracownikow()==0){
                    System.out.println("Brak pracowników");
                    break;
                }
                System.out.println("Które konto pracownika chcesz usunąć?");
                menager.wyswietlPracownikow();
                int wybor1 = wprowadzLiczbe.wprowadzInt(s);
                menager.usunPracownika(wybor1);
                break;
                        
        case 9:
            System.out.println("Zakonczono program.");
            s.close();
            return;
     }

    
}
    }catch(Exception e){
            System.out.println("Błąd wczytywania konfiguracji.");
            e.printStackTrace();
    }} 
}

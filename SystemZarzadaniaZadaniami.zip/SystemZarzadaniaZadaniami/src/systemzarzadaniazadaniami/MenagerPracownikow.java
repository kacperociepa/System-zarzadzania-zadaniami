
package systemzarzadaniazadaniami;
    
import java.util.ArrayList;
import java.util.List;

public class MenagerPracownikow {

    private List<Pracownicy> pracownicy = new ArrayList<>();

    public void dodajPracownika(String imie, String nazwisko) {
        pracownicy.add(new Pracownicy(imie, nazwisko));
        System.out.println("Konto pracownika zostalo utworzone!");
    }

    public void wyswietlPracownikow() {
       
        for (int i = 0; i < pracownicy.size(); i++) {
            Pracownicy p = pracownicy.get(i);
            System.out.println((i + 1) + ". " + p.getImie() + " " + p.getNazwisko());
        }
    }
    public Pracownicy getPracownik(int index){
        return pracownicy.get(index);
    }
    public void usunPracownika(int wybor){
        if ( wybor<1 || wybor > pracownicy.size()){
            System.out.println("Nieprawidlowy wybor pracownika!");
            return;
        }
        Pracownicy usuniety = pracownicy.remove(wybor -1 );
        
        System.out.println("Pomyslnie usunieto pracownika: "+usuniety.getImie()+ " " + usuniety.getNazwisko());
    }
    public int liczbaPracownikow(){
        return pracownicy.size();
    }
}
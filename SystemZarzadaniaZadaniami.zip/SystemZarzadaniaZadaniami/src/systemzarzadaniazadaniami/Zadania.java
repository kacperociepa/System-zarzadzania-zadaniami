
package systemzarzadaniazadaniami;


public class Zadania {
    private int id;
    private String nazwa;
    private int deadline;
    private int status;
    private static int nextId = 1;
    Pracownicy pracownik;
public int getId(){
    return id;
}
public void setId(int id){
    this.id=id;
}
public String getNazwa(){
    return nazwa;
}
public void setNazwa(String nazwa){
    this.nazwa = nazwa;
}
public int getDeadline(){
    return deadline;
}
public void setDeadline(int deadline){
    this.deadline = deadline;
}
public int getStatus(){
    return status;
}
public void setStatus(int status){
    this.status=status;
}
public Zadania(){
    id=nextId++;
    nazwa="Brak";
    deadline=0;
    status=0;
    pracownik=new Pracownicy();
}
public Zadania(String nazwa, int deadline){
    this.id=nextId++;
    this.nazwa=nazwa;
    this.deadline=deadline;
    pracownik=new Pracownicy();
}
public void przypiszPracownika(Pracownicy pracownik){
    this.pracownik=pracownik;
}
public void zmienStatus(){
    if(status==1){
        status=0;
    }
    else{
        status=1;
    }
}
public void WypiszInfo(){
    if(this.status==1){
    System.out.println("Id zadania: " + id + ", " + nazwa + " ,Zostalo do ukonczenia: " + deadline + " dni. Status: Ukonczono. Przypisany pracownik: " + pracownik.getImie()+" "+ pracownik.getNazwisko());
}else System.out.println("Id zadania: " + id + ", " + nazwa + " ,Zostalo do ukonczenia: " + deadline + " dni. Status: W trakcie. Przypisany pracownik: " + pracownik.getImie()+ " "+pracownik.getNazwisko());
}
}


package systemzarzadaniazadaniami;

public class Raport {
    private static int wTrakcie = 0;
    private static int Zakonczono = 0;
    
    
    public static void zrobRaport(Projekt projekt){
        wTrakcie=0;
        Zakonczono=0;
        for (int i = 0; i<projekt.getAktualneZadaniaSize();i++){
            Zadania z = projekt.getAktualneZadania().get(i);
            if(z.getStatus()==0){
                wTrakcie++;
            }else 
                Zakonczono++;
        }
        int suma = wTrakcie + Zakonczono;
        System.out.println("==== RAPORT PROJEKTU ====");
        System.out.println("Nazwa: "+projekt.getNazwa());
        System.out.println("Ilość zadan : "+suma);
        System.out.println("W trakcie: "+ wTrakcie);
        System.out.println("Zakocznono: "+Zakonczono);
    }
}

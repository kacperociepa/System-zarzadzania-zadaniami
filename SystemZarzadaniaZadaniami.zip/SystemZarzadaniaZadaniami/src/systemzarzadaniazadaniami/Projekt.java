package systemzarzadaniazadaniami;

import java.util.ArrayList;
import java.util.List;
public class Projekt {
       
    private int id;
    private String nazwa;
    private List<Zadania> aktualne_zadania;
    private int maxLiczbazadan;
    private static int nextId = 1;

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }
    public String getNazwa(){
        return nazwa;
    }
    public void setNazwa(String nazwa){
        this.nazwa=nazwa;
    }
    public int getLiczbazadan(){
        return aktualne_zadania.size();
    }
    public int getMaxLiczbazadan(){
        return maxLiczbazadan;
    }
    public void setMaxLiczbazadan(int maxLiczbazadan){
        this.maxLiczbazadan = maxLiczbazadan;
    }
    public List<Zadania> getAktualneZadania(){
        return aktualne_zadania;
    }
   public int getAktualneZadaniaSize(){
       return aktualne_zadania.size();
   }
    public Projekt(){
        id = nextId++;
        nazwa = "brak";
        maxLiczbazadan = 2;
        aktualne_zadania = new ArrayList<>();
    }

    public Projekt(String b, int c){
        id = nextId++;
        nazwa = b;
        maxLiczbazadan = c;
        aktualne_zadania = new ArrayList<>();
    }

    public void wyswietlInfo(){
        System.out.println("Projekt ID: "+ id + " Nazwa: "+ nazwa);
    }

    public void dodajZadanie(String nazwa, int deadline){
        if(aktualne_zadania.size() >= maxLiczbazadan){
            System.out.println("Nie mozesz dodac wiecej zadan. Osiagnieto limit: "+ maxLiczbazadan);
            return;
        }

        Zadania z = new Zadania(nazwa, deadline);
        aktualne_zadania.add(z);
        System.out.println("Pomyslnie dodano zadanie!");
    }
    public void usunZadanie(int index){
    if(index < 0 || index>=aktualne_zadania.size()){
        System.out.println("Nieprawidłowy indeks zadania.");
        return;
    }
    aktualne_zadania.remove(index);
        System.out.println("Pomyślnie usunieto zadanie!");
    }
 
    public void zmienStatus(int index){
      if(index < 0 || index>= aktualne_zadania.size()){
          System.out.println("Nieprawidlowy numer zadania.");
          return;
    }
      Zadania z = aktualne_zadania.get(index);
      z.zmienStatus();
        System.out.println("Pomyslnie zmieniono status");
    }
    public Zadania getZadanie(int index){
        return aktualne_zadania.get(index);
    }
    public void wyswietlProjekt(){
        if(id == 0){
            System.out.println("Zaden projekt nie został utworzony");
        } else {
            System.out.println("Id: " + id + ". " + nazwa + " Maksymalna ilosc zadan w tym projekcie: " + maxLiczbazadan);
        }
    }

    public void wyswietlZadania(){
        if(aktualne_zadania.isEmpty()){
            System.out.println("Brak zadan w projekcie.");
            return;
        }

        for(int i=0; i<aktualne_zadania.size();i++){
            System.out.println((i+1)+". ");
            aktualne_zadania.get(i).WypiszInfo();
        }
    }
}


package systemzarzadaniazadaniami;
import java.util.Scanner;
public class wprowadzLiczbe {
    public static int wprowadzInt(Scanner s){
        while(!s.hasNextInt()){
                System.out.println("To nie jest liczba! Sprobuj ponownie");
                s.next();
        }
        return s.nextInt();
    }
}


package systemzarzadaniazadaniami;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
public class SystemZarzadaniaZadaniami {
    
    
    
    
    
    
    
    
    
    public static void main(String[] args) {
        System.out.println("========System zarządzania zadaniami=========");
        try {
            Logowanie logowanie = new Logowanie("config.json");
                   if(!logowanie.zaloguj()){
                       System.out.println("Błędny login lub hasło!");
                       return;
                   }
            System.out.println("Zalogowano pomyślnie!");
        
        List<Projekt> projekty = new ArrayList<>();
        Scanner s = new Scanner(System.in);
        while(true){
        System.out.println("Co chcesz zrobic: ");
        System.out.println("1. Wyswietl projekty.");
        System.out.println("2. Utworz projekt");
        System.out.println("9. Wyjdz");
        
        int wybor = s.nextInt();
        switch(wybor){
            case 1:
            if(projekty.isEmpty()){
                System.out.println("Brak utworzonych projektów");
            }else {
                System.out.println("Wybierz projekt do wyswietlenia: ");
                for (int i=0; i < projekty.size(); i++){
                    System.out.println(i + 1 + ". " + projekty.get(i).getNazwa());
                }
                int projektIndex = s.nextInt() -1 ;
                if(projektIndex>= 0 && projektIndex < projekty.size()){
                    projekty.get(projektIndex).wyswietlProjekt();
                    while(true){
                    System.out.println("Co chcesz tera zrobic: ");
                    System.out.println("1. Wyswietl zadania.");
                    System.out.println("2. Dodaj zadanie.");
                    System.out.println("3. Usun zadanie.");
                    System.out.println("4. Zmien status.");
                    System.out.println("5. Zapisz zadania.");
                    System.out.println("9. Powrot.");
                    int wybor1 = s.nextInt();
                    switch(wybor1){
                        case 1:
                            projekty.get(projektIndex).wyswietlZadania();
                            break;
  
                        case 2:
                            s.nextLine();
                            System.out.println("Podaj nazwe zadania: ");
                            String nazwa = s.nextLine();
                            System.out.println("Podaj ilosc dni do ukonczenia zadania: ");
                            int deadline = s.nextInt();
                            projekty.get(projektIndex).dodajZadanie(nazwa, deadline);
                           
                            break;
                        case 3:
                        if(projekty.get(projektIndex).getLiczbazadan()==0){
                            System.out.println("Brak zadan do usuniecia.");
                            break;
                        }else System.out.println("Które zadanie chcesz usunąć?");
                            projekty.get(projektIndex).wyswietlZadania();
                            int id=s.nextInt();
                            projekty.get(projektIndex).usunZadanie(id);
                            break;
                        case 4:
                        if(projekty.get(projektIndex).getLiczbazadan()==0){
                            System.out.println("Brak zadan.");
                            break;
                        }else
                            System.out.println("Którego zadania chcesz zmienić status?");
                            projekty.get(projektIndex).wyswietlZadania();
                            id=s.nextInt();
                            projekty.get(projektIndex).zmienStatus(id);
                            break;
                        case 5:
                            s.nextLine();
                            System.out.println("Podaj nazwe pliku: ");
                            nazwa=s.nextLine();
                            boolean zapisano = Zapisywanie.zapiszZadania(projekty.get(projektIndex).getAktualneZadania(),nazwa);
                            if(zapisano){
                                System.out.println("Zadania zapisane poprawnie");
                            }else {
                                System.out.println("Bład zapisu");
                            }
                            break;
                        case 9:
                            
                            break;
                    }
                    if(wybor1 == 9 ){
                        break;
                    }
                    }
                } else {
                    System.out.println("Nieprawidlowy wybor");
                }
            }break;
            case 2:
                
            s.nextLine();
            System.out.println("Podaj nazwe projektu");
            String nazwa = s.nextLine();
            System.out.println("Podaj maksymalna liczbe zadan: ");
            int zadania = s.nextInt();
            Projekt a = new Projekt(nazwa, zadania);
            projekty.add(a);
            System.out.println("Projekt utworzony pomyslnie!");
            break;
        case 9:
            System.out.println("Zakonczono program.");
            s.close();
            return;
     }

    
}
    }catch(Exception e){
            System.out.println("Błąd wczytywania konfiguracji.");
            e.printStackTrace();
    }} 
}

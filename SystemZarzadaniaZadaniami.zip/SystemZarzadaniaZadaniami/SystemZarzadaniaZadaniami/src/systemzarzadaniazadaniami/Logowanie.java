
package systemzarzadaniazadaniami;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

public class Logowanie {
    private String login;
    private String password;
    
    public Logowanie(){
        login="Brak";
        password="Brak";
        
    }
    public Logowanie(String configPath) throws IOException {
        wczytajConfig(configPath);
    }
    
    private void wczytajConfig(String configPath) throws IOException {
        String json = Files.readString(Path.of(configPath));
        
        login = json.split("\"login\"\\s*:\\s*\"")[1].split("\"")[0];
        password = json.split("\"password\"\\s*:\\s*\"")[1].split("\"")[0];
    }
    public boolean zaloguj(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Login: ");
        String podanyLogin = sc.nextLine();
        
        System.out.println("Hasło: ");
        String podaneHaslo = sc.nextLine();
        
        return login.equals(podanyLogin) && password.equals(podaneHaslo);
}
}
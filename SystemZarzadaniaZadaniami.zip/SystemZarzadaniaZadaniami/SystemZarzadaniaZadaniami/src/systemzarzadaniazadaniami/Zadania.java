
package systemzarzadaniazadaniami;


public class Zadania {
    private int id;
    private String nazwa;
    private int deadline;
    private int status;
    private static int nextId = 1;
public int getId(){
    return id;
}
public void setId(int id){
    this.id=id;
}
public String getNazwa(){
    return nazwa;
}
public void setNazwa(String nazwa){
    this.nazwa = nazwa;
}
public int getDeadline(){
    return deadline;
}
public void setDeadline(int deadline){
    this.deadline = deadline;
}
public int getStatus(){
    return status;
}
public void setStatus(int status){
    this.status=status;
}
public Zadania(){
    id=nextId++;
    nazwa="Brak";
    deadline=0;
    status=0;
}
public Zadania(String nazwa, int deadline){
    this.id=nextId++;
    this.nazwa=nazwa;
    this.deadline=deadline;
}
public void WypiszInfo(){
    if(this.status==1){
    System.out.println("Id zadania: " + id + ", " + nazwa + " ,Zostalo do ukonczenia: " + deadline + " dni. Status: Ukonczono");
}else System.out.println("Id zadania: " + id + ", " + nazwa + " ,Zostalo do ukonczenia: " + deadline + " dni. Status: W trakcie");
}}
